module.exports = {
  publicPath: './'
  }